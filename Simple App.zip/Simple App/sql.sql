/*
SQLyog Community v12.2.6 (32 bit)
MySQL - 5.5.24-log : Database - people
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`people` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `people`;

/*Table structure for table `person` */

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `PId` int(10) NOT NULL AUTO_INCREMENT,
  `PName` varchar(50) NOT NULL,
  `PMname` varchar(50) NOT NULL,
  `PLname` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(2) NOT NULL,
  `deleted` tinyint(2) NOT NULL,
  PRIMARY KEY (`PId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `person` */

insert  into `person`(`PId`,`PName`,`PMname`,`PLname`,`Address`,`Gender`,`Age`,`deleted`) values 
(1,'arjean','haha','adiong','manay','female',20,0),
(2,'arvin','jhon','ablayan','mati','male',20,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
