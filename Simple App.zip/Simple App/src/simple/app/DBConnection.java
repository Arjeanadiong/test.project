
package simple.app;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class DBConnection {
    public static Connection connection;

    public static void databaseConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                String databaseDriver = "com.mysql.jdbc.Driver";
                String connectionURL = "jdbc:mysql://localhost:3306/people";
                String databaseUsername = "root";
                String databasePassword = "";


                Class.forName(databaseDriver);
                connection = DriverManager.getConnection(connectionURL,
                        databaseUsername,databasePassword);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"no database ask for assistance");
        }
    }
}
