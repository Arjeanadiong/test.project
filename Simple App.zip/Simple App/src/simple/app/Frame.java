/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple.app;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Junifel
 */
public class Frame extends JFrame implements ActionListener{
    
    Person p=new Person();
    JPanel panel1=new JPanel();
    JPanel panel2=new JPanel();
    DBConnection dbconnection;
    public Object[] obj=new Object[6];
    
    JLabel lblid=new JLabel("ID:");
    JLabel lblname=new JLabel("FIRSTNAME:");
    JLabel lblmname=new JLabel("MIDDLENAME:");
    JLabel lbllname=new JLabel("LASTNAME:");
    JLabel lbladdress=new JLabel("ADDRESS:");
    JLabel lblgender=new JLabel("GENDER:");
    JLabel lblage=new JLabel("AGE:");
    
    JTextField txtid=new JTextField();
    JTextField txtname=new JTextField();
    JTextField txtmname=new JTextField();
    JTextField txtlname=new JTextField();
    JTextField txtaddress=new JTextField();
    JTextField txtgender=new JTextField();
    JTextField txtage=new JTextField();
    
    
    
    JButton btninsert= new JButton("Insert");
    JButton btnupdate= new JButton("update");
    JButton btndelete= new JButton("delete");
    
    JButton insert= new JButton("Insert");
    JButton update= new JButton("update");
    JButton delete= new JButton("delete");
    
    JButton show= new JButton("Show");
    public Frame(){
        setTitle("Simple Application");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        
        panel1.setBackground(Color.gray);
        panel1.setBounds(2, 2, 500, 480);
        panel1.setLayout(null);
        panel2.setBackground(Color.gray);
        panel2.setLayout(null);
        panel2.setBounds(505,2,200,480);
        
        add(panel1);
        
        add(panel2);
        
        
        btninsert.setBounds(50,100,100,50);
        btnupdate.setBounds(50,200,100,50);
        btndelete.setBounds(50,300,100,50);
        btninsert.addActionListener(this);
        btnupdate.addActionListener(this);
        btndelete.addActionListener(this);
        show.addActionListener(this);
        update.addActionListener(this);
        panel2.add(btninsert);
        panel2.add(btnupdate);
        panel2.add(btndelete);
        
        
        lblid.setBounds(20, 50, 100, 30);
        lblname.setBounds(20, 90, 100, 30);
        lblmname.setBounds(20, 130, 100, 30);
        lbllname.setBounds(20, 170, 100, 30);
        lbladdress.setBounds(20, 210, 100, 30);
        lblgender.setBounds(20, 250, 100, 30);
        lblage.setBounds(20, 290, 110, 30);
        
        panel1.add(lblid);
        panel1.add(lblname);
        panel1.add(lblmname);
        panel1.add(lbllname);
        panel1.add(lbladdress);
        panel1.add(lblgender);
        panel1.add(lblage);
        
        txtid.setBounds(120, 50, 300, 30);
        txtname.setBounds(120, 90, 300, 30);
        txtmname.setBounds(120, 130, 300, 30);
        txtlname.setBounds(120, 170, 300, 30);
        txtaddress.setBounds(120, 210, 300, 30);
        txtgender.setBounds(120, 250, 300, 30);
        txtage.setBounds(120, 290, 300, 30);
        
        panel1.add(txtid);
        panel1.add(txtname);
        panel1.add(txtmname);
        panel1.add(txtlname);
        panel1.add(txtaddress);
        panel1.add(txtgender);
        panel1.add(txtage);
        
        insert.setBounds(200,400,100,30);
        update.setBounds(200,400,100,30);
        delete.setBounds(200,400,100,30);
        
        
        show.setBounds(300,400,100,30);
        
        panel1.add(insert);
        panel1.add(update);
        panel1.add(delete);
        panel1.add(show);
        
        insert.addActionListener(this);
         delete.addActionListener(this);
        txtid.setText("Auto generete");
        txtid.setEnabled(false);
         update.setEnabled(false);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object s=e.getSource();
        
        if(s==btninsert){
            update.setVisible(false);
            delete.setVisible(false);
            insert.setVisible(true);
            show.setVisible(false);
            
            
            txtname.setText("");
            txtmname.setText("");
            txtlname.setText("");
            txtaddress.setText("");
            txtgender.setText("");
            txtage.setText("");
            
            txtid.setText("Auto generete");
            txtid.setEnabled(false);
        }else if(s==btnupdate){
            update.setVisible(true);
            delete.setVisible(false);
            insert.setVisible(false);
            show.setVisible(true);
            update.setEnabled(false);
            
            txtname.setEnabled(false);
            txtmname.setEnabled(false);
            txtlname.setEnabled(false);
            txtaddress.setEnabled(false);
            txtgender.setEnabled(false);
            txtage.setEnabled(false);
            
             txtid.setEnabled(true);
             txtid.setText("");
        }else if(s==btndelete){
            update.setVisible(false);
            delete.setVisible(true);
            insert.setVisible(false);
            
            show.setVisible(true);
            delete.setEnabled(false);
            
            txtname.setEnabled(false);
            txtmname.setEnabled(false);
            txtlname.setEnabled(false);
            txtaddress.setEnabled(false);
            txtgender.setEnabled(false);
            txtage.setEnabled(false);
            
             txtid.setEnabled(true);
             txtid.setText("");
            
            
        }
        
 
        
        if(s==insert){
            //code here
 
            p.setPName(txtname.getText());
            p.setPLname(txtlname.getText());
            p.setPMname(txtmname.getText());
            p.setAddress(txtaddress.getText());
            p.setGender(txtgender.getText());
            p.setAge(Integer.parseInt(txtage.getText()));
            
            p.insert();
            
        }else if(s==update){
            ///code here
            
            p.setPId(Integer.parseInt(txtid.getText()));
            p.setPName(txtname.getText());
            p.setPLname(txtlname.getText());
            p.setPMname(txtmname.getText());
            p.setAddress(txtaddress.getText());
            p.setGender(txtgender.getText());
            p.setAge(Integer.parseInt(txtage.getText()));
            
            p.update();
            
        }else if(s==delete){
            //code here
            p.setPId(Integer.parseInt(txtid.getText()));
            p.delete();
            
            
        }
        else if(s==show){
            //code here
            show1();
            update.setEnabled(true);
            delete.setEnabled(true);
            txtname.setEnabled(true);
            txtmname.setEnabled(true);
            txtlname.setEnabled(true);
            txtaddress.setEnabled(true);
            txtgender.setEnabled(true);
            txtage.setEnabled(true);
            
            txtname.setText(obj[0].toString());
            txtmname.setText(obj[1].toString());
            txtlname.setText(obj[2].toString());
            txtaddress.setText(obj[3].toString());
            txtgender.setText(obj[4].toString());
            txtage.setText(obj[5].toString());
        }
    }    
    
    
    public void show1(){
        try{
            dbconnection.databaseConnection();
            PreparedStatement preparedstatement = dbconnection.connection.prepareStatement("SELECT * FROM person where PId= "+txtid.getText()+";");
            ResultSet resultset = preparedstatement.executeQuery();
            while (resultset.next()) {
                obj[0]=resultset.getString("PName");
                obj[1]=resultset.getString("PMname");
                obj[2]=resultset.getString("PLname");
                obj[3]=resultset.getString("Address");
                obj[4]=resultset.getString("Gender");
                obj[5]=resultset.getInt("Age");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
}
    
}
