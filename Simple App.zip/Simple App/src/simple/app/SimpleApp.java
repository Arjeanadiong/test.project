
package simple.app;

public class SimpleApp {

    public static void main(String[] args) {
        Frame f=new Frame();
    }
    
}
