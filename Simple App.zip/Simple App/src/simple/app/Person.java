
package simple.app;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import javax.swing.JOptionPane;


public class Person {
    
    private int PId;
    private String PName;
    private String PMname;
    private String PLname;
    private String Address;
    private String Gender;
    private int Age;
    private boolean deleted;
    

    
    public DBConnection dbconnection;
    
    public Person(){
        this.PId=0;
        this.PName="";
        this.PMname="";
        this.PLname="";
        this.Address="";
        this.Gender="";
        this.Age=0;
        this.deleted=false;
    }

    /**
     * @return the PId
     */
    public int getPId() {
        return PId;
    }

    /**
     * @param PId the PId to set
     */
    public void setPId(int PId) {
        this.PId = PId;
    }

    /**
     * @return the PName
     */
    public String getPName() {
        return PName;
    }

    /**
     * @param PName the PName to set
     */
    public void setPName(String PName) {
        this.PName = PName;
    }

    /**
     * @return the PMname
     */
    public String getPMname() {
        return PMname;
    }

    /**
     * @param PMname the PMname to set
     */
    public void setPMname(String PMname) {
        this.PMname = PMname;
    }

    /**
     * @return the PLname
     */
    public String getPLname() {
        return PLname;
    }

    /**
     * @param PLname the PLname to set
     */
    public void setPLname(String PLname) {
        this.PLname = PLname;
    }

    /**
     * @return the Address
     */
    public String getAddress() {
        return Address;
    }

    /**
     * @param Address the Address to set
     */
    public void setAddress(String Address) {
        this.Address = Address;
    }

    /**
     * @return the Gender
     */
    public String getGender() {
        return Gender;
    }

    /**
     * @param Gender the Gender to set
     */
    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    /**
     * @return the Age
     */
    public int getAge() {
        return Age;
    }

    /**
     * @param Age the Age to set
     */
    public void setAge(int Age) {
        this.Age = Age;
    }

    /**
     * @return the deleted
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * @param deleted the deleted to set
     */
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
    
    
    public void insert(){

        
        try {
            dbconnection.databaseConnection();

            PreparedStatement preparedStatement = dbconnection.connection.prepareStatement("insert into person values (null,'"+this.getPName()+"','"+this.getPMname()+"','"+this.getPLname()+"','"+this.getAddress()+"','"+this.getGender()+"',"+this.getAge()+",0);");
            
            preparedStatement.execute();
            preparedStatement.close();

            JOptionPane.showMessageDialog(null,"data added succesfully");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"please fill up all field");
           e.printStackTrace();
        }
        catch (InputMismatchException e){
            JOptionPane.showMessageDialog(null,"invalid inputs");
       }catch(NumberFormatException a){
           JOptionPane.showMessageDialog(null,"Cant add data");
       }
       catch(Exception s){
           JOptionPane.showMessageDialog(null,"Cant add data");
       }
        
    }
    
    public void update(){
        try {
            PreparedStatement preparedStatement = dbconnection.connection.prepareStatement("update person set PName='"+this.getPName()+"',PMname='"+this.getPMname()+"',PLname='"+this.getPLname()+"',Address='"+this.getAddress()+"',Gender='"+this.getGender()+"',Age="+this.getAge()+",deleted=0 where PId ="+this.getPId()+";");
            preparedStatement.execute();
            preparedStatement.close();
            JOptionPane.showMessageDialog(null,"updated sucessfully!");
        } catch (Exception ex) {
           JOptionPane.showMessageDialog(null,"can't update data!");
           ex.printStackTrace();
        }
    }
    
    
    public void delete(){
        try{
        dbconnection.databaseConnection();
        PreparedStatement preparedstatement=dbconnection.connection.prepareStatement("update person set deleted=1 where PId="+this.getPId()+";");
        preparedstatement.execute();
        preparedstatement.close();
        JOptionPane.showMessageDialog(null,"data deleted!!");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"can't delete data!");
        e.printStackTrace();
        }
    }
    
    
}
